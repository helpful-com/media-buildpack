# media-buildpack
A CF build pack containing ffmpeg, libav and other tools necessary for dealing with media files. Can be combined with other buildpacks using multi-buildpack
